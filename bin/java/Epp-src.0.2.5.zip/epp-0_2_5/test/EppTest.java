/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppTest.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xerces.parsers.*;

/* Features recognized, copied from org.apache.xerces.framework.XMLParser.java

	// SAX2 core
	"http://xml.org/sax/features/validation",
	"http://xml.org/sax/features/external-general-entities",
	"http://xml.org/sax/features/external-parameter-entities",
	"http://xml.org/sax/features/namespaces",
	// Xerces
	"http://apache.org/xml/features/validation/schema",
	"http://apache.org/xml/features/validation/dynamic",
	"http://apache.org/xml/features/validation/default-attribute-values",
	"http://apache.org/xml/features/validation/validate-content-models",
	"http://apache.org/xml/features/validation/validate-datatypes",
	"http://apache.org/xml/features/validation/warn-on-duplicate-attdef",
	"http://apache.org/xml/features/validation/warn-on-undeclared-elemdef",
	"http://apache.org/xml/features/allow-java-encodings",
	"http://apache.org/xml/features/continue-after-fatal-error",
	"http://apache.org/xml/features/nonvalidating/load-dtd-grammar",
	"http://apache.org/xml/features/nonvalidating/load-external-dtd"
	"http://apache.org/xml/features/dom/include-ignorable-whitespace"
*/

/**
 * This <code>EppTest</code> class is used for parsing and validating a
 * single XML file against XML Schema. 
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppTest implements ErrorHandler
{
	private int countWarnings = 0;
	private int countErrors = 0;
	private int countFatals = 0;

	/**
	 * The main method of the <code>EppTest</code> class
	 *
	 * @param argv argv[0] is the name of the XML file to be parsed
	 *             and validated
	 */
	public static void main( String argv[] )
	{
		if( argv.length != 1 )
		{
			System.out.println("Usage: java EppTest xmlfile");
			System.exit(0);
		}

		DOMParser parser = new DOMParser();
		EppTest test = new EppTest();

		try
		{
			parser.setFeature("http://xml.org/sax/features/validation", true);
			parser.setFeature("http://xml.org/sax/features/namespaces", true);
			parser.setFeature("http://apache.org/xml/features/validation/schema", true);
			parser.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", true);
			parser.setFeature("http://apache.org/xml/features/dom/include-ignorable-whitespace", false);

			parser.setErrorHandler(test);
			parser.parse(argv[0]);
			Document doc = parser.getDocument();
		}
		catch( Exception e )
		{
//			e.printStackTrace();
		}
		System.out.println(test);
	}

	//
	// ErrorHandler methods
	//

	//
	// Warning
	//
	public void warning( SAXParseException ex )
	{
		System.out.println("[Warning] " + getLoc(ex) + ": " + ex.getMessage());
		this.countWarnings++;
	}

	//
	// Error
	//
	public void error( SAXParseException ex )
	{
		System.out.println("[Error] " + getLoc(ex) + ": "+ ex.getMessage());
		this.countErrors++;
	}

	//
	// Fatal error
	//
	public void fatalError( SAXParseException ex ) throws SAXException
	{
		System.out.println("[Fatal Error] " + getLoc(ex) + ": "+ ex.getMessage());
		this.countFatals++;
		throw ex;
	}

	private String getLoc( SAXParseException ex )
	{
		StringBuffer buf = new StringBuffer();

		String id = ex.getSystemId();
		if( id != null )
		{
			int index = id.lastIndexOf('/');
			if( index != -1 ) 
			{
				id = id.substring(index + 1);
			}
			buf.append(id);
		}
		buf.append(':');
		buf.append(ex.getLineNumber());
		buf.append(':');
		buf.append(ex.getColumnNumber());

		return buf.toString();
	}

	public String toString()
	{
		return "EppTest: warnings=" + this.countWarnings
			+ " errors=" + this.countErrors + " fatals=" + this.countFatals;
	}
}
