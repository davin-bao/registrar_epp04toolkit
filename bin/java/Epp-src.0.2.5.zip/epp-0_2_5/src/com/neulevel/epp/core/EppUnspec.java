/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppUnspec.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core;

import org.w3c.dom.*;

/**
 * The <code>EppUnspec</code> class implement EPP unspecType objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppUnspec extends EppEntity
{
	private String value;

	/**
	 * Creates an <code>EppUnspec</code> object
	 */
	public EppUnspec()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppUnspec</code> object with a value
	 */
	public EppUnspec( String value )
	{
		this.value = value;
	}

	/**
	 * Gets the value associated with <code>EppUnspec</code> object
	 */
	public String getValue()
	{
		return this.value;
	}

	/**
	 * Sets the value associated with <code>EppUnspec</code> object
	 */
	public void setValue( String value )
	{
		this.value = value;
	}

	/**
	 * Converts an XML element into an <code>EppUnspec</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP unspecType
	 *
	 * @param root root node for an <code>EppUnspec</code> object in XML format
	 *
	 * @return an <code>EppUnspec</code> object, or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String value = EppUtil.getText(root);
		if( (value == null) || (value.trim().length() == 0) )
		{
			value = null;
		}
		return new EppUnspec(value);
	}

	/**
	 * Converts the <code>EppUnspec</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppUnspec</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm = doc.createElement(tag);
		if( value != null )
		{
			elm.appendChild(doc.createTextNode(value));
		}
		return elm;
	}

	public String toString()
	{
		return toString("unspec");
	}
}
