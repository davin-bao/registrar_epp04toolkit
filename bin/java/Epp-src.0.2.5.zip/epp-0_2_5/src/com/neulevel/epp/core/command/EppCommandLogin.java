/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandLogin.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandLogin</code> class implements EPP Command Login
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppCommandLogin extends EppCommand
{
	class EppLoginMenu extends EppServiceMenu
	{
		public EppLoginMenu( EppServiceMenu serviceMenu )
		{
			this.version = null;
			this.lang = null;
			this.svc = serviceMenu.getService();
			this.unspec = serviceMenu.getUnspec();
		}
	}

	private EppLoginMenu svcs;

	/**
	 * Creates an <code>EppCommandLogin</code> object
	 *
	 * @param serviceMenu the menu of services to be supported
	 */
	public EppCommandLogin( EppServiceMenu serviceMenu )
	{
		this.svcs = new EppLoginMenu(serviceMenu);
	}

	/**
	 * Gets the menu of services to be supported
	 */
	public EppServiceMenu getServiceMenu()
	{
		return this.svcs;
	}

	/**
	 * Sets the menu of services to be supported
	 */
	public void setServiceMenu( EppServiceMenu serviceMenu )
	{
		this.svcs = new EppLoginMenu(serviceMenu);
	}

	/**
	 * Converts the <code>EppCommandLogin</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandLogin</code>
	 *            object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		return toXMLCommon(doc, tag, svcs, "svcs", null);
	}

	/**
	 * Converts an XML element into an <code>EppCommandLogin</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Create entity.
	 *
	 * @param root root node for an <code>EppCommandLogin</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandLogin</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("svcs") )
			{
				EppServiceMenu menu = (EppServiceMenu)
						EppServiceMenu.fromXML(node);
				if( menu != null )
				{
					return new EppCommandLogin(menu);
				}
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("login");
	}
}
