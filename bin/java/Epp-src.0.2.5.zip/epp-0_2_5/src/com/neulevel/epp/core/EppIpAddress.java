/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppIpAddress.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core;

import org.w3c.dom.*;

/**
 * This <code>EppIpAddress</code> class implements EPP IP Address entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppIpAddress extends EppEntity
{
	/**
	 * IP address type for "v4"
	 */
	public static final String TYPE_V4 = "v4";
	/**
	 * IP address type for "v6"
	 */
	public static final String TYPE_V6 = "v6";

	private String ip;
	private String address;

	/**
	 * Creates an <code>EppAddress</code> object with the default
	 * address type, "v4"
	 */
	public EppIpAddress( String address )
	{
		this(address, null);
	}

	/**
	 * Creates an <code>EppAddress</code> object with an address type,
	 * either "v4" (default) or "v6"
	 */
	public EppIpAddress( String address, String type )
	{
		this.address = address;
		this.ip = type;
	}

	/**
	 * Gets the IP address type, either "v4" or "v6"
	 */
	public String getType()
	{
		return this.ip;
	}

	/**
	 * Sets the IP address type, either "v4" or "v6"
	 */
	public void setType( String type )
	{
		this.ip = type;
	}

	/**
	 * Gets the IP address
	 */
	public String getAddress()
	{
		return this.address;
	}

	/**
	 * Sets the IP address
	 */
	public void setAddress( String address )
	{
		this.address = address;
	}

	/**
	 * Converts the <code>EppIpAddress</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppIpAddress</code>
	 *              object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag)
	{
		Element body = doc.createElement(tag);
		if( ip != null )
		{
			body.setAttribute("ip", ip);
		}
		if( address != null )
		{
			body.appendChild(doc.createTextNode(address));
		}
		return body;
	}

	/**
	 * Converts an XML element into an <code>EppIpAddress</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP IP Address type.
	 *
	 * @param root root node for an <code>EppIpAddress</code> object
	 *             in XML format
	 *
	 * @return an <code>EppIpAddress</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String address = EppUtil.getText(root);
		String ip = ((Element) root).getAttribute("ip");

		return new EppIpAddress(address, ip);
	}

	public String toString()
	{
		return toString("address");
	}
}
