/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppDomain.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppDomain</code> class implements EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppDomain extends EppObject
{
	/**
	 * Contact type for administration contact ("admin");
	 */
	public static final String CONTACT_TYPE_ADMIN = "admin";
	/**
	 * Contact type for billing contact ("billing");
	 */
	public static final String CONTACT_TYPE_BILLING = "billing";
	/**
	 * Contact type for technical contact ("tech")
	 */
	public static final String CONTACT_TYPE_TECH = "tech";

	/**
	 * Domain status - clientDeleteProhibited
	 */
	public static final String STATUS_CLIENT_DELETE_PROHIBITED = "clientDeleteProhibited";
	/**
	 * Domain status - clientHold
	 */
	public static final String STATUS_CLIENT_HOLD = "clientHold";
	/**
	 * Domain status - clientRenewProhibited
	 */
	public static final String STATUS_CLIENT_RENEW_PROHIBITED = "clientRenewProhibited";
	/**
	 * Domain status - clientTransferProhibited
	 */
	public static final String STATUS_CLIENT_TRANSFER_PROHIBITED = "clientTransferProhibited";
	/**
	 * Domain status - clientUpdateProhibited
	 */
	public static final String STATUS_CLIENT_UPDATE_PROHIBITED = "clientUpdateProhibited";
	/**
	 * Domain status - inactive
	 */
	public static final String STATUS_INACTIVE = "inactive";
	/**
	 * Domain status - ok
	 */
	public static final String STATUS_OK = "ok";
	/**
	 * Domain status - pendingDelete
	 */
	public static final String STATUS_PENDING_DELETE = "pendingDelete";
	/**
	 * Domain status - pendingTransfer
	 */
	public static final String STATUS_PENDING_TRANSFER = "pendingTransfer";
	/**
	 * Domain status - pendingVerification
	 */
	public static final String STATUS_PENDING_VERIFICATION = "pendingVerification";
	/**
	 * Domain status - serverDeleteProhibited
	 */
	public static final String STATUS_SERVER_DELETE_PROHIBITED = "serverDeleteProhibited";
	/**
	 * Domain status - serverHold
	 */
	public static final String STATUS_SERVER_HOLD = "serverHold";
	/**
	 * Domain status - serverRenewProhibited
	 */
	public static final String STATUS_SERVER_RENEW_PROHIBITED = "serverRenewProhibited";
	/**
	 * Domain status - serverTransferProhibited
	 */
	public static final String STATUS_SERVER_TRANSFER_PROHIBITED = "serverTransferProhibited";
	/**
	 * Domain status - serverUpdateProhibited
	 */
	public static final String STATUS_SERVER_UPDATE_PROHIBITED = "serverUpdateProhibited";

	private String    name;
	private Vector    host;
	private Vector    ns;
	private Vector    contact;
	private EppPeriod period;
	private String    registrant;

	/**
	 * Creates an <code>EppDomain</code> object
	 */
	public EppDomain()
	{
		this.host    = new Vector();
		this.ns      = new Vector();
		this.contact = new Vector();
	}

	/**
	 * Creates an <code>EppDomain</code> object with a domain name
	 */
	public EppDomain( String name )
	{
		this();
		this.name = name;
	}

	/**
	 * Gets the domain name
	 */
	public String getName()
	{
		return this.name;
	}

	/**
	 * Sets the domain name
	 */
	public void setName( String name )
	{
		this.name = name;
	}

	/**
	 * Gets a list of host names associated with the domain
	 */
	public Vector getHost()
	{
		return this.host;
	}

	/**
	 * Adds a host name associated with the domain
	 *
	 * @note this method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addHost( String host )
	{
		this.host.addElement(host);
	}

	/**
	 * Gets a list of name servers associated with the domain
	 */
	public Vector getNameServer()
	{
		return this.ns;
	}

	/**
	 * Add a name server associated with the domain
	 */
	public void addNameServer( String nameServer )
	{
		this.ns.addElement(nameServer);
	}

	/**
	 * Gets a list of contacts associated with the domain
	 */
	public Vector getContact()
	{
		return this.contact;
	}

	/**
	 * Adds a contact for the domain
	 */
	public void addContact( EppContactType contact )
	{
		this.contact.addElement(contact);
	}

	/**
	 * Adds a contact for the domain, given a contact id and its type
	 */
	public void addContact( String id, String type )
	{
		this.contact.addElement(new EppContactType(id, type));
	}

	/**
	 * Gets registration period for the domain name
	 */
	public EppPeriod getPeriod()
	{
		return this.period;
	}

	/**
	 * Sets registration period for the domain name
	 */
	public void setPeriod( EppPeriod period )
	{
		this.period = period;
	}

	/**
	 * Gets the contact id of the registrant which owns the domain
	 */
	public String getRegistrant()
	{
		return this.registrant;
	}

	/**
	 * Sets the contact id of the registrant which owns the domain
	 */
	public void setRegistrant( String registrant )
	{
		this.registrant = registrant;
	}

	/**
	 * Converts the <code>EppDomain</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppDomain</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "domain", tag);
		boolean isCreate = tag.equals("create");

		// the order of the tags for create is:
		//
		// name/period/ns/registrant/contact/authInfo
		//
		// the order of the tags for info is
		//
		// name/roid/status/registrant/contact/ns/host/clID/crID/crDate
		// upDate/exDate/trDate/authInfo
		//
		// so the tricky part is to put ns ahead of registrant for
		// a create tag, and ns after contact for an info tag

		if( name != null )
		{
			elm = doc.createElement("name");
			elm.appendChild(doc.createTextNode(name));
			body.appendChild(elm);
		}
		if( period != null )
		{
			body.appendChild(period.toXML(doc, "period"));
		}
		if( roid != null )
		{
			elm = doc.createElement("roid");
			elm.appendChild(doc.createTextNode(roid));
			body.appendChild(elm);
		}
		if( status != null )
		{
			for( int i = 0; i < status.size(); i++ )
			{
				EppStatus s = (EppStatus) status.elementAt(i);
				body.appendChild(s.toXML(doc, "status"));
			}
		}

		// ns for a create tag

		if( isCreate && (ns != null) )
		{
			for( int i = 0; i < ns.size(); i++ )
			{
				String s = (String) ns.elementAt(i);
				elm = doc.createElement("ns");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}
		if( registrant != null )
		{
			elm = doc.createElement("registrant");
			elm.appendChild(doc.createTextNode(registrant));
			body.appendChild(elm);
		}
		if( contact != null )
		{
			for( int i = 0; i < contact.size(); i++ )
			{
				EppContactType c = (EppContactType) contact.elementAt(i);
				body.appendChild(c.toXML(doc, "contact"));
			}
		}

		// ns for an info tag

		if( ! isCreate && (ns != null) )
		{
			for( int i = 0; i < ns.size(); i++ )
			{
				String s = (String) ns.elementAt(i);
				elm = doc.createElement("ns");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}
		if( host != null )
		{
			for( int i = 0; i < host.size(); i++ )
			{
				String s = (String) host.elementAt(i);
				elm = doc.createElement("host");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}

		toXMLCommon(doc, body);

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppDomain</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Domain type.
	 *
	 * @param root root node for an <code>EppDomain</code> object in
	 *             XML format
	 *
	 * @return an <code>EppDomain</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppDomain domain = new EppDomain();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("name") )
			{
				domain.setName(EppUtil.getText(node));
			}
			else if( name.equals("host") )
			{
				domain.addHost(EppUtil.getText(node));
			}
			else if( name.equals("ns") )
			{
				domain.addNameServer(EppUtil.getText(node));
			}
			else if( name.equals("contact") )
			{
				EppContactType c = (EppContactType) EppContactType.fromXML(node);
				if( c != null )
				{
					domain.addContact(c);
				}
			}
			else if( name.equals("period") )
			{
				EppPeriod p = (EppPeriod) EppPeriod.fromXML(node);
				if( p != null )
				{
					domain.setPeriod(p);
				}
			}
			else if( name.equals("registrant") )
			{
				domain.setRegistrant(EppUtil.getText(node));
			}
			else if( name.equals("authInfo") )
			{
				EppAuthInfo authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
				if( authInfo != null )
				{
					domain.setAuthInfo(authInfo);
				}
			}
			else
			{
				domain.fromXMLCommon(node, name);
			}
		}

		return domain;
	}

	public String toString()
	{
		return toString("domain");
	}

	/**
	 * Creates an <code>EppCommandDeleteDomain</code> object for
	 * deleting an EPP Domain object from the registry.
	 *
	 * @param name the name of the domain object to be deleted
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandDeleteDomain delete( String name, String xid )
	{
		return new EppCommandDeleteDomain(name, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoDomain</code> object for
	 * querying the details of an EPP Domain object
	 *
	 * @param name the name of the domain object to be queried
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandInfoDomain info( String name, String xid )
	{
		return new EppCommandInfoDomain(name, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckDomain</code> object for
	 * checking the existance of EPP Domain objects in the registry.
	 * Names of EPP Domain objects can be added via the
	 * <code>add</code> or <code>addName</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckDomain check( String xid )
	{
		return new EppCommandCheckDomain(xid);
	}

	/**
	 * Creates an <code>EppCommandTransferDomain</code> object for
	 * transfering an EPP Domain object in the registry. The operation
	 * type, registration period and authorization information associated
	 * with the operation should be specified via <code>setPeriod</code>,
	 * <code>setOperation</code> and <code>setAuthInfo</code> method.
	 *
	 * @param name   the name of the domain object to be transferred
	 * @param period the extended registration period of the domain object,
	 *               or null if there is no change in the expiration
	 *               timestamp of the domain object after the transfer
	 *               operation
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandTransferDomain transfer( String name, EppPeriod period, String xid )
	{
		return new EppCommandTransferDomain(name, period, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateDomain</code> object for
	 * updating an EPP Domain object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateDomain</code> object.
	 *
	 * @param name the name of the domain object to be updated
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandUpdateDomain update( String name, String xid )
	{
		return new EppCommandUpdateDomain(name, xid);
	}

	/**
	 * Creates an <code>EppCommandRenewDomain</code> object for
	 * renewing the registration of an EPP Domain object in the registry.
	 *
	 * @param name       the name of the domain object to be renewed
	 * @param curExpDate the current expiration date of the domain object
	 * @param period     the new registration period of the domain object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewDomain renew( String name, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewDomain(name, curExpDate, period, xid);
	}
}
