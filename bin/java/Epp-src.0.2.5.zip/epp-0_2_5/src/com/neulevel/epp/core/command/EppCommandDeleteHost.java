/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteHost.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandDeleteHost</code> class implements EPP Command Delete
 * entity for EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
public class EppCommandDeleteHost extends EppCommandDelete
{
	private String name;

	/**
	 * Creates an <code>EppCommandDeleteHost</code> object for
	 * deleting a host object based on its name
	 */
	public EppCommandDeleteHost( String name )
	{
		this(name, null);
	}

	/**
	 * Creates an <code>EppCommandDeleteHost</code> object for
	 * deleting a host object based on its name, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandDeleteHost( String name, String xid )
	{
		this.name = name;
		this.clTRID = xid;
	}

	/**
	 * Gets the name of the host object to be deleted
	 */
	public String getName()
	{
		return this.name;
	}

	/**
	 * Sets the name of the host object to be deleted
	 */
	public void setName( String name )
	{
		this.name = name;
	}

	/**
	 * Converts the <code>EppCommandDeleteHost</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteHost</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "host", tag);

		if( name != null )
		{
			elm = doc.createElement("name");
			elm.appendChild(doc.createTextNode(name));
			body.appendChild(elm);
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandDeleteHost</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP host object.
	 *
	 * @param root root node for an <code>EppCommandDeleteHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteHost</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("name") )
			{
				String s = EppUtil.getText(node);
				return new EppCommandDeleteHost(s);
			}
		}

		return null;
	}
}
