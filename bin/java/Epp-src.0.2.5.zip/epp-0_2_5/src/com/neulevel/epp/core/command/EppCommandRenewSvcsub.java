/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandRenewSvcsub</code> class implements EPP Command Renew
 * entity for EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$
 */
public class EppCommandRenewSvcsub extends EppCommandRenew
{
	private String id;
	private String userid;
	private EppAuthInfo authInfo;

	/**
	 * Creates an <code>EppCommandRenewSvcsub</code> object with a
	 * default expiration period, specified by the registry
	 */
	public EppCommandRenewSvcsub( String id, Calendar curExpDate )
	{
		this(id, curExpDate, null, null);
	}

	/**
	 * Creates an <code>EppCommandRenewSvcsub</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	public EppCommandRenewSvcsub( String id, String xid )
	{
		this(id, Calendar.getInstance(), null, xid);
	}

	/**
	 * Creates an <code>EppCommandRenewSvcsub</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	public EppCommandRenewSvcsub( String id, Calendar curExpDate, String xid )
	{
		this(id, curExpDate, null, xid);
	}

	/**
	 * Creates an <code>EppCommandRenewSvcsub</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	public EppCommandRenewSvcsub( String id, Calendar curExpDate, EppPeriod period, String xid )
	{
		this.id = id;
		this.curExpDate = curExpDate;
		this.period = period;
		this.userid = null;
		this.clTRID = xid;
	}

	/**
	 * Gets the id of the service subscription object to be renewed
	 */
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the id of the service subscription object to be renewed
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Gets the user id that can be used for authorization purpose
	 */
	public String getUserId()
	{
		return this.userid;
	}
	
	/**
	 * Sets the user id that can be used for authorization purpose
	 */
	public void setUserId( String userid )
	{
		this.userid = userid;
	}

	/**
	 * Gets the authorization info for the renew operation
	 */
	public EppAuthInfo getAuthInfo()
	{
		return this.authInfo;
	}

	/**
	 * Sets the authorization info for the renew operation
	 */
	public void setAuthInfo( EppAuthInfo authInfo )
	{
		this.authInfo = authInfo;
	}

	/**
	 * Converts the <code>EppCommandRenewSvcsub</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewSvcsub</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "svcsub", tag);

		if( id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(id));
			body.appendChild(elm);
		}
		if( curExpDate != null )
		{
			elm = doc.createElement("curExpDate");
			elm.appendChild(EppUtil.createTextNode(doc, curExpDate, true));
			body.appendChild(elm);
		}
		if( period != null )
		{
			body.appendChild(period.toXML(doc, "period"));
		}
		if( userid != null )
		{
			elm = doc.createElement("userid");
			elm.appendChild(doc.createTextNode(userid));
			body.appendChild(elm);
		}
		if( authInfo != null )
		{
			body.appendChild(authInfo.toXML(doc, "authInfo"));
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandRenewSvcsub</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP svcsub object
	 *
	 * @param root root node for an <code>EppCommandRenewSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandRenewSvcsub cmd = null;
		String id = null;
		String userid = null;
		Calendar curExpDate = null;
		EppPeriod period = null;
		EppAuthInfo authInfo = null;

		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				id = EppUtil.getText(node);
			}
			else if( name.equals("curExpDate") )
			{
				curExpDate = EppUtil.getDate(node, true);
			}
			else if( name.equals("period") )
			{
				period = (EppPeriod) EppPeriod.fromXML(node);
			}
			else if( name.equals("userid") )
			{
				userid = EppUtil.getText(node);
			}
			else if( name.equals("authInfo") )
			{
				authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
			}
		}
		cmd = new EppCommandRenewSvcsub(id, curExpDate, period, null);
		if( cmd != null )
		{
			cmd.setAuthInfo(authInfo);
			cmd.setUserId(userid);
		}

		return cmd;
	}
}
