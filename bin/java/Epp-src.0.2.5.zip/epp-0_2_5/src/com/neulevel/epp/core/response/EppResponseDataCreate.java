/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreate.java,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
package com.neulevel.epp.core.response;

import com.neulevel.epp.core.*;

/**
 * This <code>EppResponseDataCreate</code> class implements EPP Response
 * Data entity for EPP Command Create.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
abstract public class EppResponseDataCreate extends EppResponseData
{
	/**
	 * The ROID associated with the response data after creating
	 * an object sucessfully
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	protected String roid;

	/**
	 * Gets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	public String getRoid()
	{
		return this.roid;
	}

	/**
	 * Sets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	public void setRoid( String roid )
	{
		this.roid = roid;
	}
}
