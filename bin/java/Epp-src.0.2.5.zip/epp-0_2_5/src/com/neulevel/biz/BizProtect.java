/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.biz;

/**
 * This <code>BizProtect</code> class defines various services ids
 * in the BIZprotect product suite.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$
 */
public class BizProtect
{
	/**
	 * Service ID for BIZ Account
	 */
	public static final String BIZ_ACCOUNT = "BIZaccount";

	/**
	 * Service ID for BIZ Lock
	 */
	public static final String BIZ_LOCK = "BIZlock";
}
