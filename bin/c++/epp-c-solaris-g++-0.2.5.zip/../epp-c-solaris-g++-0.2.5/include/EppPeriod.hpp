#if ! defined(EPPPERIOD_HPP)    /* { */
#define       EPPPERIOD_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppPeriod.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppPeriod</code> class implements EPP Domain periodType entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppPeriod : public EppEntity
{
private:
	int  value;
	char unit;

public:
	/**
	 * Period unit for year ('y')
	 */
	static const char UNIT_YEAR;
	/**
	 * Period unit for month ('m')
	 */
	static const char UNIT_MONTH;

	/**
	 * Creates an <code>EppPeriod</code> object, with default value
	 * 1 and unit of 'm'
	 */
	EppPeriod()
	{
		this->value = 1;
		this->unit  = UNIT_YEAR;
	};

	/**
	 * Creates an <code>EppPeriod</code> object
	 */
	EppPeriod( int value, char unit )
	{
		this->value = value;
		this->unit  = unit;
	};

	/**
	 * Destructor
	 */
	~EppPeriod() {};

	/**
	 * Gets the value of the period
	 */
	int getValue()
	{
		return this->value;
	};

	/**
	 * Sets the value of the period
	 */
	void setValue( int value )
	{
		this->value = value;
	};

	/**
	 * Gets the unit of the period
	 */
	char getUnit()
	{
		return this->unit;
	};

	/**
	 * Sets the unit of the period, either 'y' for year or 'm' for month
	 */
	void setUnit( char unit )
	{
		this->unit = unit;
	};

	/**
	 * Converts the <code>EppPeriod</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppPeriod</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppPeriod</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Period type.
	 *
	 * @param root root node for an <code>EppPeriod</code> object
	 *             in XML format
	 *
	 * @return an <code>EppPeriod</code> object, or null if the node
	 *         is invalid
	 */
	static EppPeriod * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("period"));
	};
};

#endif     /* EPPPERIOD_HPP */  /* } */
