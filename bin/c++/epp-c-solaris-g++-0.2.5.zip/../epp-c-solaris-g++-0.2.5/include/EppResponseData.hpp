#if ! defined(EPPRESPONSEDATA_HPP)    /* { */
#define       EPPRESPONSEDATA_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppResponseData.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppResponseData</code> class implements EPP Response Data entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppResponseData : public EppEntity
{
public:
	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseData;
	};

	/**
	 * Converts an XML element into an <code>EppResponseData</code> object.
	 * The caller of this method must make sure that the root node is the
	 * resData element of EPP responseType
	 *
	 * @param root root node for an <code>EppResponseData</code> object in
	 *             XML format
	 *
	 * @return an <code>EppResponseData</code> object, or null if the node
	 *         is invalid
	 */
	static EppResponseData * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("resData"));
	};
};

#endif     /* EPPRESPONSEDATA_HPP */  /* } */
