#if ! defined(EPPRESPONSEDATACREATE_HPP)    /* { */
#define       EPPRESPONSEDATACREATE_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreate.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppResponseData.hpp"

/**
 * This <code>EppResponseDataCreate</code> class implements EPP Response
 * Data entity for EPP Command Create.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppResponseDataCreate : public EppResponseData
{
protected:
	/**
	 * The ROID associated with the response data after creating
	 * an object successfully
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString roid;

public:
	/**
	 * Creates <code>EppResponseDataCreate</code> object
	 */
	EppResponseDataCreate()
	{
		this->roid = null;
	};

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataCreate() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreate;
	};

	/**
	 * Gets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString getRoid()
	{
		return this->roid;
	};

	/**
	 * Sets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	void setRoid( DOMString roid )
	{
		this->roid = roid;
	};
};

#endif     /* EPPRESPONSEDATACREATE_HPP */  /* } */
