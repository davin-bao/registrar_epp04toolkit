#if        ! defined(BIZPROTECT_HPP)    /* { */
#define              BIZPROTECT_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#if ! defined(EPP_EXPORT)    /* { */
#define       EPP_EXPORT
#endif     /* EPP_EXPORT) */ /* } */

/**
 * This <code>BizLock</code> class defines various constants and methods related
 * to the BIZlock service.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$
 */
class EPP_EXPORT BizLock
{
public:
	/**
	 * Service ID for BIZ lock
	 * @note this &lt;service&gt; element is REQUIRED when the object is
	 *       created and cannot be changed via the &lt;update&gt; command.
	 *       It can have only one instance
	 */
	static const char * ID;
	/**
	 * Service parameter for the domain name to be locked
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and cannot be changed via the &lt;update&gt; command. It can have
	 *       only one instance. The domain must be already registered in
	 *       the registry
	 */
	static const char * PARAM_DOMAIN;
	/**
	 * Service parameter for the authinfo (password) associated
	 * with the domain name to be locked.
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and can have only one instance. It SHOULD not be returned
	 *       in the response of an &lt;info&gt; command. The domain must be
	 *       already registered in the registry
	 */
	static const char * PARAM_DOMAIN_AUTHINFO;
	/**
	 * Service parameter for the BIZaccount to be associated with
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and cannot be changed via the &lt;update&gt; command. It can have
	 *       only one instance
	 */
	static const char * PARAM_BIZACCOUNT;
	/**
	 * Service parameter for the UserID associated with registrant
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and can have only one instance. It SHOULD not be returned
	 *       in the response of an &lt;info&gt; command.
	 */
	static const char * PARAM_USERID;
	/**
	 * Service parameter for the password associated with registrant
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and can have only one instance. It SHOULD not be returned
	 *       in the response of an &lt;info&gt; command.
	 */
	static const char * PARAM_PASSWORD;
	/**
	 * Service parameter for the BIZlock type. It can be two values:
	 * <UL>
	 *     <LI>soft</LI>
	 *     <LI>hard</LI>
	 * </UL>
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and cannot be changed via the &lt;update&gt; command. It can have
	 *       only one instance
	 */
	static const char * PARAM_LOCKTYPE;
	/**
	 * Service parameter value for the BIZlock type: <I>soft</I>,
	 * i.e. the BIZlock Select&153; service.
	 */
	static const char * VALUE_LOCKTYPE_SOFT;
	/**
	 * Service parameter value for the BIZlock type: <I>hard</I>,
	 * i.e. the BIZlock Basic&153; service.
	 */
	static const char * VALUE_LOCKTYPE_HARD;
	/**
	 * Service parameter for the state of the lock. It can be two values:
	 * <UL>
	 *     <LI>on</LI>
	 *     <LI>off</LI>
	 * </UL>
	 *
	 * @note this &lt;param&gt; element is REQUIRED when the object is created
	 *       and CAN BE changed via the &lt;update&gt; command. It can have
	 *       only one instance
	 */
	static const char * PARAM_LOCKSTATE;
	/**
	 * Service parameter value for the state of the lock: on
	 */
	static const char * VALUE_LOCKSTATE_ON;
	/**
	 * Service parameter value for the state of the lock: off
	 */
	static const char * VALUE_LOCKSTATE_OFF;
};

#endif  /* ! defined(BIZPROTECT_HPP) */ /* } */
