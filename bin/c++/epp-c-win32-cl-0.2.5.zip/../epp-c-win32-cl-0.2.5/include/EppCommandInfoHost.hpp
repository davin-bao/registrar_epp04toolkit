#if ! defined(EPPCOMMANDINFOHOST_HPP)    /* { */
#define       EPPCOMMANDINFOHOST_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoHost.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfoHost</code> class implements EPP Command Info
 * entity for EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandInfoHost : public EppCommandInfo
{
private:
	DOMString name;

public:
	/**
	 * Creates an <code>EppCommandInfoHost</code> object
	 */
	EppCommandInfoHost()
	{
		this->name = null;
	};

	/**
	 * Creates an <code>EppCommandInfoHost</code> object for
	 * querying a host object based on its name
	 */
	EppCommandInfoHost( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Creates an <code>EppCommandInfoHost</code> object for
	 * querying a host object based on its name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoHost( DOMString name, DOMString xid )
	{
		this->name = name;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoHost() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoHost;
	};

	/**
	 * Gets the name of the host object to be queried
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the host object to be queried
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Converts the <code>EppCommandInfoHost</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoHost</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoHost</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP host object.
	 *
	 * @param root root node for an <code>EppCommandInfoHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoHost</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoHost * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOHOST_HPP */  /* } */
