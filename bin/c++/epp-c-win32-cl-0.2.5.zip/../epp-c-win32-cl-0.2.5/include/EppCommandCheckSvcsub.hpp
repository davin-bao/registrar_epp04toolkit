#if ! defined(EPPCOMMANDCHECKSVCSUB_HPP)    /* { */
#define       EPPCOMMANDCHECKSVCSUB_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_SVCSUB_IDS	16

/**
 * This <code>EppCommandCheckSvcsub</code> class implements EPP Command Check
 * entity for EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$
 */
class EPP_EXPORT EppCommandCheckSvcsub : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * ids;

public:
	/**
	 * Creates an <code>EppCommandCheckSvcsub</code> object
	 */
	EppCommandCheckSvcsub()
	{
		this->ids = new ValueVectorOf<DOMString>(MAX_NUM_OF_SVCSUB_IDS);
	};

	/**
	 * Creates an <code>EppCommandCheckSvcsub</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckSvcsub( DOMString xid )
	{
		this->ids = new ValueVectorOf<DOMString>(MAX_NUM_OF_SVCSUB_IDS);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckSvcsub()
	{
		if( this->ids != null )
		{
			delete this->ids;
			this->ids = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckSvcsub;
	};

	/**
	 * Gets the list of the ids of the subscription objects to be checked
	 */
	ValueVectorOf<DOMString> * getId()
	{
		return this->ids;
	};

	/**
	 * Gets the list of the ids of the subscription objects to be checked
	 *
	 * @note this is an alias for <code>getId</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getId();
	};

	/**
	 * Adds the id of a subscription object to the list of ids of subscription
	 * objects be checked
	 */
	void addId( DOMString id )
	{
		this->ids->addElement(id);
	};

	/**
	 * Adds the id of a subscription object to the list of ids of subscription
	 * objects be checked
	 *
	 * @note this is an alias for <code>addId</code>
	 */
	void add( DOMString id )
	{
		this->addId(id);
	};

	/**
	 * Converts the <code>EppCommandCheckSvcsub</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckSvcsub</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP Svcsub objects.
	 *
	 * @param root root node for an <code>EppCommandCheckSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckSvcsub * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKSVCSUB_HPP */  /* } */
