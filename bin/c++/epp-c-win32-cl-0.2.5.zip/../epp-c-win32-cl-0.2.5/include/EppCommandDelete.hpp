#if ! defined(EPPCOMMANDDELETE_HPP)    /* { */
#define       EPPCOMMANDDELETE_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDelete.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppCommand.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandDelete : public EppCommand
{
public:
	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDelete;
	};

	/**
	 * Converts an XML element into an <code>EppCommandDelete</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Delete entity.
	 *
	 * @param root root node for an <code>EppCommandDelete</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandDelete</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandDelete * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("delete"));
	};
};

#endif     /* EPPCOMMANDDELETE_HPP */  /* } */
