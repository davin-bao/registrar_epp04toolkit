#if ! defined(EPPCOMMANDUPDATESVCSUB_HPP)    /* { */
#define       EPPCOMMANDUPDATESVCSUB_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandUpdate.hpp"
#include "EppContactType.hpp"
#include "EppSvcsubParam.hpp"
#include "EppAuthInfo.hpp"

#define	MAX_NUM_OF_UPDATE_SVCPARAMS	16
#define	MAX_NUM_OF_UPDATE_SVCCONTACTS	16
	
/**
 * This <code>EppCommandUpdateSvcsub</code> class implements EPP Command Update
 * entity for EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$
 */
class EPP_EXPORT EppCommandUpdateSvcsub : public EppCommandUpdate
{
private:
	DOMString                       id;
	ValueVectorOf<EppSvcsubParam> * paramAdded;
	ValueVectorOf<EppSvcsubParam> * paramRemoved;
	ValueVectorOf<EppContactType> * contactAdded;
	ValueVectorOf<EppContactType> * contactRemoved;
	DOMString                       newRegistrant;
	EppAuthInfo                   * newAuthInfo;
	DOMString                       userid;
	EppAuthInfo                   * authInfo;

	/**
	 * Converts a list of service parameters into XML
	 *
	 * @param doc  the XML <code>DOM_Element</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of parameters is appended
	 * @param list the list of parameters to be converted
	 */
	void paramToXML( DOM_Document& doc, DOM_Element& body, ValueVectorOf<EppSvcsubParam> * list );

	/**
	 * Converts a list of contacts into XML
	 *
	 * @param doc  the XML <code>DOM_Element</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of contacts is appended
	 * @param list the list of contacts to be converted
	 */
	void contactToXML( DOM_Document& doc, DOM_Element& body, ValueVectorOf<EppContactType> * list );

	/**
	 * Converts a list of service parameters from XML format
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of parameters
	 * @param addressList the list of parameters to be stored
	 */
	void paramFromXML( const DOM_Node& root, ValueVectorOf<EppSvcsubParam> * paramList );

	/**
	 * Converts a list of contacts from XML format
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of contacts
	 * @param contactList the list of contacts to be stored
	 */
	void contactFromXML( const DOM_Node& root, ValueVectorOf<EppContactType> * contactList );

public:
	/**
	 * Creates an <code>EppCommandUpdateSvcsub</code>
	 */
	EppCommandUpdateSvcsub()
	{
		this->id             = null;
		this->paramAdded     = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->paramRemoved   = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->contactAdded   = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->contactRemoved = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->newRegistrant  = null;
		this->newAuthInfo    = null;
		this->userid         = null;
		this->authInfo       = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateSvcsub</code> given the id of the
	 * svcsub object
	 */
	EppCommandUpdateSvcsub( DOMString id )
	{
		this->id             = id;
		this->paramAdded     = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->paramRemoved   = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->contactAdded   = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->contactRemoved = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->newRegistrant  = null;
		this->newAuthInfo    = null;
		this->userid         = null;
		this->authInfo       = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateSvcsub</code> given the id of the
	 * svcsub object
	 */
	EppCommandUpdateSvcsub( DOMString id, DOMString xid )
	{
		this->id             = id;
		this->paramAdded     = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->paramRemoved   = new ValueVectorOf<EppSvcsubParam>(MAX_NUM_OF_UPDATE_SVCPARAMS);
		this->contactAdded   = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->contactRemoved = new ValueVectorOf<EppContactType>(MAX_NUM_OF_UPDATE_SVCCONTACTS);
		this->newRegistrant  = null;
		this->newAuthInfo    = null;
		this->userid         = null;
		this->authInfo       = null;
		this->clTRID         = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandUpdateSvcsub()
	{
		if( this->paramAdded != null )
		{
			delete this->paramAdded;
			this->paramAdded = null;
		}
		if( this->paramRemoved != null )
		{
			delete this->paramRemoved;
			this->paramRemoved = null;
		}
		if( this->contactAdded != null )
		{
			delete this->contactAdded;
			this->contactAdded = null;
		}
		if( this->contactRemoved != null )
		{
			delete this->contactRemoved;
			this->contactRemoved = null;
		}
		if( this->newAuthInfo != null )
		{
			delete this->newAuthInfo;
			this->newAuthInfo = null;
		}
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateSvcsub;
	};

	/**
	 * Gets the id of the svcsub object to be updated
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the svcsub object to be updated
	 */
	void setId( DOMString& id )
	{
		this->id = id;
	};

	/**
	 * Gets the list of new parameters to be added to the svcsub object
	 */
	ValueVectorOf<EppSvcsubParam> * getParamAdded()
	{
		return this->paramAdded;
	};

	/**
	 * Adds a new parameter to be associated with the svcsub object
	 */
	void addParam( EppSvcsubParam& param )
	{
		this->paramAdded->addElement(param);
	};

	/**
	 * Gets the list of old parameters to be removed from the svcsub object
	 */
	ValueVectorOf<EppSvcsubParam> * getParamRemoved()
	{
		return this->paramRemoved;
	};

	/*
	 * Removes an old parameter associated with the svcsub object
	 */
	void removeParam( EppSvcsubParam& param )
	{
		this->paramRemoved->addElement(param);
	};

	/**
	 * Gets the list of new contacts to be added to the svcsub object
	 */
	ValueVectorOf<EppContactType> * getContactAdded()
	{
		return this->contactAdded;
	};

	/**
	 * Adds a new contact to be associated with the svcsub object
	 */
	void addContact( EppContactType& contact )
	{
		this->contactAdded->addElement(contact);
	};

	/**
	 * Gets the list of old contacts to be removed from the svcsub object
	 */
	ValueVectorOf<EppContactType> * getContactRemoved()
	{
		return this->contactRemoved;
	};

	/*
	 * Removes an old contact associated with the svcsub object
	 */
	void removeContact( EppContactType& contact )
	{
		this->contactRemoved->addElement(contact);
	};

	/**
	 * Gets the new registrant's contact id for the svcsub object,
	 * or null if the registrant of the svcsub object is not to be changed
	 */
	DOMString getNewRegistrant()
	{
		return this->newRegistrant;
	};

	/**
	 * Sets the new registrant's contact id for the svcsub object,
	 * if a new registrant claims the ownership of the svcsub object
	 */
	void setNewRegistrant( DOMString registrant )
	{
		this->newRegistrant = registrant;
	};

	/**
	 * Gets the new authorization information for the svcsub object, or null
	 * if the authorization information of the svcsub object is not to be
	 * changed
	 */
	EppAuthInfo * getNewAuthInfo()
	{
		return this->newAuthInfo;
	};

	/**
	 * Sets the new authorization information for the svcsub object if it
	 * needs to be changed
	 */
	void setNewAuthInfo( EppAuthInfo& authInfo )
	{
		if( this->newAuthInfo == null )
		{
			this->newAuthInfo = new EppAuthInfo();
		}
		*(this->newAuthInfo) = authInfo;
	};

	/**
	 * Gets the user id that can be used for authorization purpose
	 */
	DOMString getUserId()
	{
		return this->userid;
	};

	/**
	 * Sets the user id that can be used for authorization purpose
	 */
	void setUserId( DOMString userid )
	{
		this->userid = userid;
	};

	/**
	 * Gets the authorization information for the update operation
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization information for the update operation
	 */
	void setAuthInfo( EppAuthInfo& authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Converts the <code>EppCommandUpdateSvcsub</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateSvcsub</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP Svcsub object.
	 *
	 * @param root root node for an <code>EppCommandUpdate</code> object
	 *	     in XML format
	 *
	 * @return an <code>EppCommandUpdateSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateSvcsub * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATESVCSUB_HPP */  /* } */
