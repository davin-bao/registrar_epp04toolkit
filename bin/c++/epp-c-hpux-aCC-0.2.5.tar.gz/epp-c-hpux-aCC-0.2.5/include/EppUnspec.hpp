#if ! defined(EPPUNSPEC_HPP)    /* { */
#define       EPPUNSPEC_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppUnspec.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppEntity.hpp"

/**
 * The <code>EppUnspec</code> class implement EPP unspecType objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppUnspec : public EppEntity
{
private:
	DOMString value;

public:
	/**
	 * Creates an <code>EppUnspec</code> object
	 */
	EppUnspec()
	{
		value = null;
	};

	/**
	 * Creates an <code>EppUnspec</code> object with a value
	 */
	EppUnspec( DOMString value )
	{
		this->value = value;
	};

	/**
	 * Destructor
	 */
	~EppUnspec() {};

	/**
	 * Gets the value associated with <code>EppUnspec</code> object
	 */
	DOMString getValue()
	{
		return this->value;
	};

	/**
	 * Sets the value associated with <code>EppUnspec</code> object
	 */
	void setValue( const DOMString& value )
	{
		this->value = value;
	};

	/**
	 * Converts the <code>EppUnspec</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppUnspec</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document &doc, const DOMString &tag );

	/**
	 * Converts an XML element into an <code>EppUnspec</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP unspecType
	 *
	 * @param root root node for an <code>EppUnspec</code> object in XML format
	 *
	 * @return an <code>EppUnspec</code> object, or null if the node is invalid
	 */
	static EppUnspec * fromXML( const DOM_Node &root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("unspec"));
	};
};

#endif     /* EPPUNSPEC_HPP */  /* } */
