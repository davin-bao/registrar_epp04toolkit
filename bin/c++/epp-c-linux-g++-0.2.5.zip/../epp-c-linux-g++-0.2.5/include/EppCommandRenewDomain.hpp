#if ! defined(EPPCOMMANDRENEWDOMAIN_HPP)    /* { */
#define       EPPCOMMANDRENEWDOMAIN_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandRenewDomain.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewDomain</code> class implements EPP Command Renew
 * entity for EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandRenewDomain : public EppCommandRenew
{
private:
	DOMString    name;

public:
	/**
	 * Creates an <code>EppCommandRenewDomain</code> object
	 */
	EppCommandRenewDomain()
	{
		this->name = null;
	};

	/**
	 * Creates an <code>EppCommandRenewDomain</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewDomain( DOMString name, time_t curExpDate )
	{
		this->name = name;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewDomain</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewDomain( DOMString name, DOMString xid )
	{
		this->name = name;
		this->curExpDate = time(0);
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewDomain</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewDomain( DOMString name, time_t curExpDate, DOMString xid )
	{
		this->name = name;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewDomain</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewDomain( DOMString name, time_t curExpDate, EppPeriod& period, DOMString xid )
	{
		this->name = name;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	}

	/**
	 * Destructor
	 */
	~EppCommandRenewDomain() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewDomain;
	};

	/**
	 * Gets the name of the domain to be renewed
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the domain to be renewed
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Converts the <code>EppCommandRenewDomain</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewDomain</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewDomain</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP domain object
	 *
	 * @param root root node for an <code>EppCommandRenewDomain</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewDomain</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewDomain * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWDOMAIN_HPP */  /* } */
