#if ! defined(EPPHELLO_HPP)    /* { */
#define       EPPHELLO_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppHello.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppHello</code> class implements EPP Hello entity used in
 * the EPP Protocol initialization.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppHello : public EppEntity
{
public:
	/**
	 * Creates an <code>EppHello</code> object
	 */
	EppHello() {};

	/**
	 * Destructor
	 */
	~EppHello() {};

	/**
	 * Converts the <code>EppHello</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppHello</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppHello</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP addrType.
	 *
	 * @param root root node for an <code>EppHello</code> object in XML
	 *             format
	 *
	 * @return an <code>EppHello</code> object, or null if the node
	 *         is invalid
	 */
	static EppHello * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("hello"));
	};
};

#endif     /* EPPHELLO_HPP */  /* } */
