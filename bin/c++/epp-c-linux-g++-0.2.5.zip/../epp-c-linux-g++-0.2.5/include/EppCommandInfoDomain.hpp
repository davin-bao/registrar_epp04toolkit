#if ! defined(EPPCOMMANDINFODOMAIN_HPP)    /* { */
#define       EPPCOMMANDINFODOMAIN_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoDomain.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfoDomain</code> class implements EPP Command Info
 * entity for EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandInfoDomain : public EppCommandInfo
{
private:
	DOMString name;

public:
	/**
	 * Creates an <code>EppCommandInfoDomain</code> object for
	 */
	EppCommandInfoDomain()
	{
		this->name = null;
	};

	/**
	 * Creates an <code>EppCommandInfoDomain</code> object for
	 * querying a domain object based on its name
	 */
	EppCommandInfoDomain( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Creates an <code>EppCommandInfoDomain</code> object for
	 * querying a domain object based on its name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoDomain( DOMString name, DOMString xid )
	{
		this->name = name;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoDomain() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoDomain;
	};

	/**
	 * Gets the name of the domain object to be queried
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the domain object to be queried
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Converts the <code>EppCommandInfoDomain</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoDomain</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoDomain</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP domain object.
	 *
	 * @param root root node for an <code>EppCommandInfoDomain</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoDomain</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoDomain * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFODOMAIN_HPP */  /* } */
