#if ! defined(EPPRESPONSEDATACHECKHOST_HPP)    /* { */
#define       EPPRESPONSEDATACHECKHOST_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckHost.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckHost</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppResponseDataCheckHost : public EppResponseDataCheck
{
public:
	/**
	 * Creates an <code>EppResponseDataCheckHost</code> object
	 */
	EppResponseDataCheckHost() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckHost() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckHost;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckHost</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Host object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckHost</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckHost</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckHost * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckHost</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckHost</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKHOST_HPP */  /* } */
