#if ! defined(EPPCONTACTTYPE_HPP)    /* { */
#define       EPPCONTACTTYPE_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppContactType.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppEntity.hpp"
#include "util/ValueVectorOf.hpp"

/**
 * This <code>EppContactType</code> class implements EPP Contact Type entity.
 * Currently, only EPP Domain objects have contact types defined:
 *
 * <UL>
 * <LI><B>EPP Domain Object</B><UL>
 *     <LI>billing</LI>
 *     <LI>admin</LI>
 *     <LI>tech</LI>
 *     </UL></LI>
 * </UL>
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppContactType : public EppEntity
{
private:
	DOMString id;
	DOMString type;

public:
	/**
	 * Creates an <code>EppContactType</code> object
	 */
	EppContactType()
	{
		this->id = null;
		this->type = null;
	};

	/**
	 * Creates an <code>EppContactType</code> object with the id of
	 * a contact object and a type string
	 */
	EppContactType( DOMString id, DOMString type )
	{
		this->id = id;
		this->type = type;
	};

	/**
	 * Destructor
	 */
	~EppContactType() {};

	/**
	 * Gets the id of the contact
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the contact
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the type of the contact
	 */
	DOMString getType()
	{
		return this->type;
	};

	/**
	 * Sets the type of the contact
	 */
	void setType( DOMString type )
	{
		this->type = type;
	};

	/**
	 * Gets a sub-list of contact ids, given a list of contact types
	 * and a type string
	 *
	 * @param contact a list of EppContactType objects
	 * @param type the type of contacts to be extracted from the list
	 *
	 * @return a list of contact ids, or null if not found
	 * @note the caller must free the returned list if not null
	 */
	static ValueVectorOf<DOMString> * getContactId( ValueVectorOf<EppContactType> * contact, DOMString type );

	/**
 	 * Converts the <code>EppContactType</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppContactType</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppContactType</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Contact Type type.
	 *
	 * @param root root node for an <code>EppContactType</code> object
	 *             in XML format
	 *
	 * @return an <code>EppContactType</code> object, or null if the node
	 *         is invalid
	 */
	static EppContactType * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("contact"));
	};
};

#endif     /* EPPCONTACTTYPE_HPP */  /* } */
