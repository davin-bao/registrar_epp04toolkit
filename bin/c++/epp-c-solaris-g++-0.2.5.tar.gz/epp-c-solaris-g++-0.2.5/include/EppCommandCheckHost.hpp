#if ! defined(EPPCOMMANDCHECKHOST_HPP)    /* { */
#define       EPPCOMMANDCHECKHOST_HPP        1
/*
 * Copyright (c) 2001 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id: EppCommandCheckHost.hpp,v 1.1 2001/11/05 20:20:36 zhang Exp $
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_HOST_NAMES	16

/**
 * This <code>EppCommandCheckHost</code> class implements EPP Command Check
 * entity for EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandCheckHost : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * names;

public:
	/**
	 * Creates an <code>EppCommandCheckHost</code> object
	 */
	EppCommandCheckHost()
	{
		this->names = new ValueVectorOf<DOMString>(MAX_NUM_OF_HOST_NAMES);
	};

	/**
	 * Creates an <code>EppCommandCheckHost</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckHost( DOMString xid )
	{
		this->names = new ValueVectorOf<DOMString>(MAX_NUM_OF_HOST_NAMES);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckHost()
	{
		if( this->names != null )
		{
			delete this->names;
			this->names = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckHost;
	};

	/**
	 * Gets the list of the names of the host objects to be checked
	 */
	ValueVectorOf<DOMString> * getName()
	{
		return this->names;
	};

	/**
	 * Gets the list of the names of the host objects to be checked
	 *
	 * @note this is an alias for <code>getName</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getName();
	};

	/**
	 * Adds a hot name to the the list of the names of the host objects
	 * to be checked
	 */
	void addName( DOMString name )
	{
		this->names->addElement(name);
	};

	/**
	 * Adds a hot name to the the list of the names of the host objects
	 * to be checked
	 *
	 * @note this is an alias for <code>addName</code>
	 */
	void add( DOMString name )
	{
		this->addName(name);
	};

	/**
	 * Converts the <code>EppCommandCheckHost</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckHost</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckHost</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP Host objects.
	 *
	 * @param root root node for an <code>EppCommandCheckHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckHost</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckHost * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKHOST_HPP */  /* } */
